export {
  FirebaseAuthProvider as AuthProvider,
  useFirebaseAuth as useAuth,
} from "../hooks/useFirebaseAuth";
